import { Component } from '@angular/core';

@Component({
  selector: 'app-guesthome',
  imports: [],
  templateUrl: './guesthome.component.html',
  styleUrl: './guesthome.component.css'
})
export class GuesthomeComponent {

}
