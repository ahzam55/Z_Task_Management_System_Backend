import { Component } from '@angular/core';

@Component({
  selector: 'app-userhome',
  imports: [],
  templateUrl: './userhome.component.html',
  styleUrl: './userhome.component.css'
})
export class UserhomeComponent {

}
